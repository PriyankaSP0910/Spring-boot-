package com.example.prg5_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prg5JavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Prg5JavaApplication.class, args);
	}

}
